#!/usr/bin/python
import os,time

def re_mount():
	remount_cmd="adb shell mount -o remount,rw /system"
	os.system(remount_cmd)

def push_shellscript():
	psh_shellscript_cmd="adb push exec_me.sh /system/bin/"
	os.system(psh_shellscript_cmd)
	os.system("adb shell chmod 777 /system/bin/exec_me.sh")


re_mount()
push_shellscript()

for x in range(0,600000):
	fname="file"+str(x)+".png"
	psh_cmd="adb push /home/android/Desktop/fuzzed_files/data/"+fname+" /system/bin/pngtest.png"
	print psh_cmd
	os.system(psh_cmd)
	os.system("adb shell /system/bin/exec_me.sh")
	time.sleep(1)
	

