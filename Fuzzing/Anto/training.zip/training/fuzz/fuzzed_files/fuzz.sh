#!/bin/bash
 
# file size
filesize=4201
 
# file offset
off=0
 
# number of files
num=50
 
# fuzz value
val=255
 
# name counter
cnt=0
 
while [ $cnt -lt $num ]
do
	cp ./testcase.png ./file$cnt.png
	./fuzz $filesize $off $val ./file$cnt.png
	let "off+=1"
	let "cnt+=1"
done
